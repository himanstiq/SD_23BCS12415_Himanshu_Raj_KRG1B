#include <iostream>
#include <unordered_map>
#include <memory>
#include <string>

class TrieNode {
public:
    std::unordered_map<char, std::unique_ptr<TrieNode>> children;
    bool isEndOfWord;

    TrieNode() : isEndOfWord(false) {}
};

class Trie {
private:
    std::unique_ptr<TrieNode> root;

public:
    Trie() {
        root = std::make_unique<TrieNode>();
    }

    void insert(const std::string& word) {
        TrieNode* node = root.get();
        for (char ch : word) {
            if (node->children.find(ch) == node->children.end()) {
                node->children[ch] = std::make_unique<TrieNode>();
            }
            node = node->children[ch].get();
        }
        node->isEndOfWord = true;
    }

    bool search(const std::string& word) const {
        TrieNode* node = root.get();
        for (char ch : word) {
            if (node->children.find(ch) == node->children.end()) {
                return false;
            }
            node = node->children.at(ch).get();
        }
        return node->isEndOfWord;
    }

    bool startsWith(const std::string& prefix) const {
        TrieNode* node = root.get();
        for (char ch : prefix) {
            if (node->children.find(ch) == node->children.end()) {
                return false;
            }
            node = node->children.at(ch).get();
        }
        return true;
    }
};


int main(){
    
}